var Person = (function () {
    function Person(name, age) {
        this.name = name;
        this.age = age;
    }
    return Person;
}());
var person1 = new Person("anand", 21);
console.log('Pesron Name :${person1.name}');
