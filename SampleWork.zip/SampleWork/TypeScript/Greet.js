var Grretme = (function () {
    function Grretme() {
    }
    Grretme.prototype.greet = function () {
        console.log("Hello World");
    };
    return Grretme;
}());
var obj = new Grretme();
obj.greet();
//-----------------------------------------data Type-----------------------------------------
var name1 = "John";
var score1 = 50;
var score2 = 42.50;
var sum = score1 + score2;
console.log("name" + name);
console.log("first score: " + score1);
console.log("second score: " + score2);
console.log("sum of the scores: " + sum);
//-----------------------------------------changing the type of str from string to integer-----------------------------------------
var str = '1';
var str2 = str; //str is now of type number 
console.log(str2);
//-----------------------------------------Scope of Variable -----------------------------------------
var global_num = 12; //global variable 
var Numbers = (function () {
    function Numbers() {
        this.num_val = 13; //class variable 
    }
    Numbers.prototype.storeNum = function () {
        var local_num = 14; //local variable 
    };
    return Numbers;
}());
Numbers.sval = 10; //static field 
console.log("Global num: " + global_num);
console.log(Numbers.sval); //static variable  
var obj1 = new Numbers();
console.log("Global num: " + obj1.num_val);
// ---------------------Conditional OPerator --> Test ? expr1 : expr2 -----------------------------------------
var num = -2;
var result = num > 0 ? "positive" : "non-positive";
console.log(result);
//................................. Looping ............................................
var n = 5;
while (n > 5) {
    console.log("Entered while");
}
do {
    console.log("Entered do…while");
} while (n > 5);
// ............................... Break Statement ...........................
var i = 1;
while (i <= 10) {
    if (i % 5) {
        console.log("multiple of 5 found");
        break;
    }
    i++;
}
//...................Continue statemet ....................................................
var num = 0;
var count = 0;
for (num = 0; num <= 20; num++) {
    if (num % 2 == 0) {
        continue;
    }
    count++;
}
console.log("the count of odd value beetween 0 and 20" + count);
//................................ optional Parameter..............................................
function disp_details(id, name, mail__id) {
    console.log("ID", id);
    console.log("name", name);
    if (mail__id != undefined)
        console.log("Email id:", mail__id);
}
disp_details(123, "abc");
disp_details(111, "as", "abc.com");
//...................................Rest Parameter .......................................
function addNumbers() {
    var nums = [];
    for (var _i = 0; _i < arguments.length; _i++) {
        nums[_i] = arguments[_i];
    }
    var i;
    var sum = 0;
    for (i = 0; i < nums.length; i++) {
        sum = sum + nums[i];
    }
    console.log("sum of the numbers", sum);
}
addNumbers(1, 2, 3);
addNumbers(10, 10, 10, 10, 10);
//...................................... Default Parameer ..............................
function calculate_discount(price, rate) {
    if (rate === void 0) { rate = 0.50; }
    var discount = price * rate;
    console.log("Discount Amount: ", discount);
}
calculate_discount(1000);
calculate_discount(1000, 0.30);
//..........................anonyms function .................................................
var msg = function () {
    return "hello world";
};
console.log(msg());
//.................................. Function Constructor .......................................
var myFunction = new Function("a", "b", "return a * b");
var x = myFunction(4, 3);
console.log(x);
//..................... Rcursive function ...........................
function factorial(number) {
    if (number <= 0) {
        return 1;
    }
    else {
        return (number * factorial(number - 1)); // function invokes itself
    }
}
;
console.log(factorial(6)); // outputs 720 
// ....................................... Lambda Expresssion ...........................................
var foo = function (x) { return 10 + x; };
console.log(foo(100)); //outputs 110 
//................................. Number ...............................
console.log("TypeScript Number Properties: ");
console.log("Maximum value that a number variable can hold: " + Number.MAX_VALUE);
console.log("The least value that a number variable can hold: " + Number.MIN_VALUE);
console.log("Value of Negative Infinity: " + Number.NEGATIVE_INFINITY);
console.log("Value of Negative Infinity:" + Number.POSITIVE_INFINITY);
// ................................ Array ............................................
var alphas;
alphas = ["1", "2", "3", "4"];
console.log(alphas[0]);
console.log(alphas[1]);
/////////////
var arr_names = new Array(4);
for (var i = 0; i < arr_names.length; i++)
    ;
{
    arr_names[i] = i * 2;
    console.log(arr_names[i]);
}
//.............................. Tuple............................................
var mytuple = [10, "Hello"]; //create a  tuple 
console.log(mytuple[0]);
console.log(mytuple[1]);
