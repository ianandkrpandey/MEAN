class Person{
    constructor(public name:string,public age:number){

    }
}
let person1 = new Person("anand",21);
console.log('Pesron Name :${person1.name}');
