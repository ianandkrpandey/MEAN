var myName:String="anand";
var height:Number=5;
var canJump:Boolean=true;
var anything:any="anyvalue"