//Type of variable used in Typescript

let mystr:string ='akp';
let myarr:string[] = ['a','b','c'];
let myarr1:Array<string> = ['a','b','cs'];
let myTuple:[string,number] = ['a',1,1];
let myNull:null=null;
let myUndefined:undefined=undefined;

console.log(myUndefined);

//Function Defination

function mySum(num1,num2){
    return num1+num2;
}
function mySum1(num1:number,num2:number):number{
    return num1+num2;
}
console.log(mySum(1,4));

//Interfaces

interface myInterface{
    name:string;
    email:string;
    age:number;
    canVote:boolean;


}
//Classes

class User {
name:string;
    email:string;
    age:number;
    canVote:boolean;
    constructor(name,email,age,canVote){
        this.name = name;
        this.email= email;
        this.age=age;
        this.canVote=canVote;
        function canVoteO(age:number){
if(age>=18){
    console.log(''canVote)
}
        }
        
    }
}