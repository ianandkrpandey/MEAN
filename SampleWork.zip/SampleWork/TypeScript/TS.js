//Type of variable used in Typescript
var mystr = 'akp';
var myarr = ['a', 'b', 'c'];
var myarr1 = ['a', 'b', 'c'];
var myTuple = ['a', 1, 1];
var myNull = null;
var myUndefined = undefined;
console.log(myUndefined);
//Function Defination
function mySum(num1, num2) {
    return num1 + num2;
}
function mySum1(num1, num2) {
    return num1 + num2;
}
console.log(mySum(1, 4));
//Classes
var User = (function () {
    function User(name, email, age, canVote) {
        this.name = name;
        this.email = email;
        this.age = age;
        this.canVote = canVote;
        function canVoteO(age) {
        }
    }
    return User;
}());
