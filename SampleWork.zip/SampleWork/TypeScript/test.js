var person = { "name": "John", "age": 31, "city": "New York" };
person.age = "a";
var myObj, x;
myObj = { "name": "John", "age": 30, "city": "New York" };
myObj["name"] = "Gilbert";
document.getElementById("demo").innerHTML = myObj.name;