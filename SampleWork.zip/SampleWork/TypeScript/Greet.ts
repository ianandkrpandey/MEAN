class Grretme{
greet():void{
    console.log("Hello World")
}

}
var obj = new Grretme();
obj.greet();

//-----------------------------------------data Type-----------------------------------------
var name1:string = "John"; 
var score1:number = 50;
var score2:number = 42.50
var sum = score1 + score2 
console.log("name"+name) 
console.log("first score: "+score1) 
console.log("second score: "+score2) 
console.log("sum of the scores: "+sum)


//-----------------------------------------changing the type of str from string to integer-----------------------------------------
var str = '1' 
var str2:number = <number> <any> str   //str is now of type number 
console.log(str2)

//-----------------------------------------Scope of Variable -----------------------------------------
var global_num = 12          //global variable 
class Numbers { 
   num_val = 13;             //class variable 
   static sval = 10;         //static field 
   
   storeNum():void { 
      var local_num = 14;    //local variable 
   } 
} 
console.log("Global num: "+global_num)  
console.log(Numbers.sval)   //static variable  
var obj1 = new Numbers(); 
console.log("Global num: "+obj1.num_val)

// ---------------------Conditional OPerator --> Test ? expr1 : expr2 -----------------------------------------
var num:number = -2 
var result = num > 0 ?"positive":"non-positive" 
console.log(result)

//................................. Looping ............................................
var n:number = 5 
while(n > 5) { 
   console.log("Entered while") 
} 
do { 
   console.log("Entered do…while") 
} 
while(n>5)

// ............................... Break Statement ...........................
var i=1;
while(i<=10){
    if(i%5){
        console.log("multiple of 5 found")
        break;

    }
    i++
}
//...................Continue statemet ....................................................
var num:number =0;
var count:number=0;
for(num =0;num<=20;num++){
    if(num%2==0){
continue;
    }
    count++;
}
console.log("the count of odd value beetween 0 and 20"+count)

//................................ optional Parameter..............................................

function disp_details(id:number,name:string,mail__id?:string){
    console.log("ID",id);
    console.log("name",name)
    if(mail__id!=undefined)
    console.log("Email id:",mail__id);
}
disp_details(123,"abc")
disp_details(111,"as","abc.com")

//...................................Rest Parameter .......................................
function addNumbers(...nums:number[]) {  
   var i;   
   var sum:number = 0; 
   
   for(i = 0;i<nums.length;i++) { 
      sum = sum + nums[i]; 
   } 
   console.log("sum of the numbers",sum) 
} 
addNumbers(1,2,3) 
addNumbers(10,10,10,10,10)

//...................................... Default Parameer ..............................
function calculate_discount(price:number,rate:number = 0.50) { 
   var discount = price * rate; 
   console.log("Discount Amount: ",discount); 
} 
calculate_discount(1000) 
calculate_discount(1000,0.30)

//..........................anonyms function .................................................
var msg = function() { 
   return "hello world";  
} 
console.log(msg())

//.................................. Function Constructor .......................................

var myFunction = new Function("a", "b", "return a * b"); 
var x = myFunction(4, 3); 
console.log(x);

//..................... Rcursive function ...........................
function factorial(number) {
   if (number <= 0) {         // termination case
      return 1; 
   } else {     
      return (number * factorial(number - 1));     // function invokes itself
   } 
}; 
console.log(factorial(6));      // outputs 720 

// ....................................... Lambda Expresssion ...........................................
var foo = (x:number)=>10 + x 
console.log(foo(100))      //outputs 110 

//................................. Number ...............................

console.log("TypeScript Number Properties: "); 
console.log("Maximum value that a number variable can hold: " + Number.MAX_VALUE); 
console.log("The least value that a number variable can hold: " + Number.MIN_VALUE); 
console.log("Value of Negative Infinity: " + Number.NEGATIVE_INFINITY); 
console.log("Value of Negative Infinity:" + Number.POSITIVE_INFINITY);

// ................................ Array ............................................
var alphas:string[]; 
alphas = ["1","2","3","4"] 
console.log(alphas[0]); 
console.log(alphas[1]);

/////////////
var arr_names:number[] = new Array(4)  

for(var i = 0;i<arr_names.length;i++;) { 
   arr_names[i] = i * 2 
   console.log(arr_names[i]) 
}

//.............................. Tuple............................................

var mytuple = [10,"Hello"]; //create a  tuple 
console.log(mytuple[0]) 
console.log(mytuple[1])

//................................... Union .............................................

var val:string|number 
val = 12 
console.log("numeric value of val "+val) 
val = "This is a string" 
console.log("string value of val "+val)

//////////
var arr:number[]|string[]; 
var i:number; 
arr = [1,2,4] 
console.log("**numeric array**")  

for(i = 0;i<arr.length;i++) { 
   console.log(arr[i]) 
}  

arr = ["Mumbai","Pune","Delhi"] 
console.log("**string array**")  

for(i = 0;i<arr.length;i++) { 
   console.log(arr[i]) 
} 

//.................................... Interface ............................
interface IPerson { 
   firstName:string, 
   lastName:string, 
   sayHi: ()=>string 
} 

var customer:IPerson = { 
   firstName:"Tom",
   lastName:"Hanks", 
   sayHi: ():string =>{return "Hi there"} 
} 

console.log("Customer Object ") 
console.log(customer.firstName) 
console.log(customer.lastName) 
console.log(customer.sayHi())  

var employee:IPerson = { 
   firstName:"Jim",
   lastName:"Blakes", 
   sayHi: ():string =>{return "Hello!!!"} 
} 
  
console.log("Employee  Object ") 
console.log(employee.firstName) 
console.log(employee.lastName)

//.........................union and Interface ...........................

interface RunOptions { 
   program:string; 
   commandline:string[]|string|(()=>string); 
} 

//commandline as string 
var options:RunOptions = {program:"test1",commandline:"Hello"}; 
console.log(options.commandline)  

//commandline as a string array 
options = {program:"test1",commandline:["Hello","World"]}; 
console.log(options.commandline[0]); 
console.log(options.commandline[1]);  

//commandline as a function expression 
options = {program:"test1",commandline:()=>{return "**Hello World**";}}; 

var fn:any = options.commandline; 
console.log(fn());

// ..............................Classes and Interface...........................................

interface ILoan { 
   interest:number 
} 

class AgriLoan implements ILoan { 
   interest:number 
   rebate:number 
   
   constructor(interest:number,rebate:number) { 
      this.interest = interest 
      this.rebate = rebate 
   } 
} 

var obj2 = new AgriLoan(10,1) 
console.log("Interest is : "+obj2.interest+" Rebate is : "+obj2.rebate )
var myjson = JSON.stringify(obj2)
var jsonData = JSON.parse(myjson)
