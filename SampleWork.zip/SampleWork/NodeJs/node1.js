var x = 0;

do {
    x++;
    console.log("x: " + x);
} while (x < 5);