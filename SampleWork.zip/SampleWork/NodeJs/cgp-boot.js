import boot = require('cgp-boot');
let boot1: boot.Boot = boot.Boot.getInstance();
boot1.bootstrap().then(() => {
    console.log('all started');
}).catch((e) => {
    console.log('all failed', e);
});