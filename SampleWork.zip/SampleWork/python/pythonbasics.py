import random
import  sys
import os

print ("python basics")

name = "anand"
print (name)
name = 1
print(name)
'''
multi line comment
'''
#Arthmatic operation
print("5 + 2 =", 5+2)
print("5 - 2 =", 5-2)
print("5 * 2 =", 5*2)
print("5 / 2 =", 5/2)
print("5 % 2 =", 5%2)
print("5 ** 2 =", 5**2)
print("5 // 2 =", 5//2)

# we can use bracket in arthmatic operation

print("1 + 2 - 3 * 2 =", 1 + 2 - 3 * 2)
print("(1 + 2 - 3) * 2 =", (1 + 2 - 3) * 2)

quote = "\"Quote Using\""
print(quote)
multi_line_quote = '''
Line 1
line 2
line 3
'''
print(multi_line_quote)
new_string = quote+multi_line_quote
print(new_string)

print("%s %s %s" % ('I like quote',quote,multi_line_quote))
print('\n'*4)
print("print this after 4 line")

# Using List
grocery_list = ['juice','potato','sugar','rice']
print('First item is',grocery_list[0])
grocery_list[0] = "Green Juice"
print('First item is change',grocery_list[0])
print(grocery_list[1:3])
other_event =['read python','read node','read type script']
add_list=[other_event,grocery_list]
print(other_event,grocery_list)
print(add_list)
# Retrive items from list

print((add_list[0][1]))
add_list.append('new item')
print(add_list)

grocery_list.insert(4,"pickel")
print(grocery_list)
print(grocery_list.sort())
grocery_list.remove("pickel")
print(grocery_list)
del grocery_list[2]
print(grocery_list)
# Merge two list

new_list = grocery_list + other_event
# some Operation in list
print("New List Items--->",new_list)
print(len(new_list))
print(max(new_list))
print(min(new_list))

# Tuple Example

pi_tuple = (1,2,3,4,5,6,7)
print(pi_tuple)
new_tuple = list(pi_tuple)
new_tuple = tuple(new_tuple)

# Dictionaries Example

key_value = {'one':1,
             'two':2,
             'three':3,
             'four':4}

print(key_value['four'])
print(key_value.get("four"))
print(key_value.keys())
print(key_value.values())

# Conditional OPERATOR

age =21
if age >16:
    print('you are eligible for party')
else:
    print('you are not eligible for party')


    if age>=21:
        print("Eligible for driving truck")
    elif age>=16:
        print ("eligible for driving a car")
    else:
        print("not Eligible for driving")

# LOGICAL Operator

if((age >=1) and (age<=18)):
    print("celebrate B'day")
elif(age >21) or (age<65):
    print("No Celebration")
elif not(age==30):
    print ("You are 30")
else:
    print ("Birthday Over")

# for Loop

for y in grocery_list:
    print (y)
    num_list = [[1,3,5,7,9],[2,4,6,8,0],[0,1,2,3,4,5]]
    for x in range(0,5):
        for y in range(0,5):
            print (num_list[x][y])
print ("---------------------------------------")
# while Loop


i = 0
while(i<=20):
        if(i%2==0):
            print(i)
        elif(i==9):
            break
        else:
            i+=1
            continue








