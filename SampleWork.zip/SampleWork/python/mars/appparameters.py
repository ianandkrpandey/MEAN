""" ************************************************************************
#  Description: calculation of MD5 checksums for DSX files - needs Python 2.6
#
#   $RCSfile: appparameters.py,v $
#    $Source: /var/cvs/ftps/ftps/tools/python/appparameters.py,v $
#      $Date: 2012/03/26 14:51:26 $
#    $Author: ttuerks $
#  $Revision: 1.3 $
#
#  (c) Copyright 2009 rockwell automation solutions gmbh, D-76227 Karlsruhe
# ************************************************************************
"""
vcsid = '$Header: /var/cvs/ftps/ftps/tools/python/appparameters.py,v 1.3 2012/03/26 14:51:26 ttuerks Exp $'


import glob
import os
import re
import string
import sys

reBooleanString = 'getMESConfiguration[\s]*\(\)[\s]*.getBoolean[\s]*\([\s]*"(?P<name>[\S ]+?)"[^"]*"(?P<comment>.*?)"\)'
reBoolean       = re.compile(reBooleanString, re.DOTALL)
reLongString    = 'getMESConfiguration[\s]*\(\)[\s]*.getLong[\s]*\([\s]*"(?P<name>[\S ]+?)"[^"]*"(?P<comment>.*?)"\)'
reLong          = re.compile(reLongString, re.DOTALL)
reStringString = 'getMESConfiguration[\s]*\(\)[\s]*.getString[\s]*\([\s]*"(?P<name>[\S ]+?)"(?P<comment>.+?)[\s]*?"[\s]*\)[\s]*;'
reString       = re.compile(reStringString, re.DOTALL)

_javaFileExtension    = '.java'


def _usage():
  print ""
  print "Usage: allparameters[.py] <directory>"
  print "  <directory>: the directory in the filesystem where the Java sources are"
  print "  scans the Java source files and extracts a description for all application parameters used."
  sys.exit()


def main(startDirectory):
  javaFiles = []
  matches   = []
  directories = _getAllSubDirectories(startDirectory)
  for directory in directories:
    fileNames = glob.glob(directory + '/*' + _javaFileExtension)
    for fileName in fileNames:
      javaFiles.append(fileName)
  for item in javaFiles:
    parseFile(item, matches)
  lines = generateReport(matches)
  for line in lines:
    print line


def generateReport(matches):
  reportLines = []
  reportLines.append('-' * 70)
  reportLines.append('Comments')
  reportLines.append('-' * 70 + '\n')
  matches.sort(_compareCaseInsensitive)
  if matches:
    maxNameSize = max([len(item[0]) for item in matches])
    for name, description in matches:
      reportLines.append('%s %s: %s' % (name, ' '*(maxNameSize - len(name)), description))
  return reportLines


def parseFile(fileName, matches):
  someFile = open(fileName, 'r')
  content = someFile.read()
  [_addHitToMatches(hit, matches) for hit in re.findall(reBoolean, content)]
  [_addHitToMatches(hit, matches) for hit in re.findall(reLong, content)]
  [_addStringHitToMatches(hit, matches) for hit in re.findall(reString, content)]
  someFile.close()


def _addHitToMatches(hit, matches):
    names = [name for name, comment in matches]
    name, remark = hit
    if name not in names and _prettify(remark):
      matches.append((name, _prettify(remark)))


def _addStringHitToMatches(hit, matches):
    names = [name for name, comment in matches]
    name, remark = hit
    if name not in names and _prettifyForString(remark):
      matches.append((name, _prettifyForString(remark)))


def _prettify(remarkForString):
  remarkForString = remarkForString.replace('"', '')
  remarkForString = remarkForString.replace('+', '')
  remarkForString = remarkForString.replace('\n', '')
  remarkForString = string.join(remarkForString.split(), ' ')
  return remarkForString


def _prettifyForString(remarkForString):
  return remarkForString.split('"')[-1:][0]


def _compareCaseInsensitive(left, right):
  left = left[0].lower()
  right = right[0].lower()
  if left < right:
    return -1
  elif left > right:
    return 1
  else:
    return 0

def _getAllSubDirectories(startDirectory):
  directories = []
  pathNames = [f[0] for f in [glob.glob(d[0]) for d in os.walk(startDirectory)] if f]
  pathNames = [item.upper() for item in pathNames if not item.upper().endswith('CVS')]
  for pathName in pathNames:
    if os.path.isdir(pathName):
      directories.append(os.path.abspath(pathName))
  return directories


if __name__ == '__main__':
  allArguments = []

  # process command line arguments, i.e. split them into options and parameter
  idx = 1
  while idx < len(sys.argv):
    allArguments.append(sys.argv[idx])
    idx = idx + 1

  if len(allArguments) != 1:
    _usage()
  else:
    main(allArguments[0])
