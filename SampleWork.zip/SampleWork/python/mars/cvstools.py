""" ************************************************************************
#  Description: produces a list of modified file for the DO in PD trace based on a DO number and
#               a starting directory
#
#   $RCSfile: cvstools.py,v $
#    $Source: /var/cvs/ftps/ftps/tools/python/cvstools.py,v $
#      $Date: 2013/03/22 08:54:16 $
#    $Author: rweinga $
#  $Revision: 1.3 $
#
#  (c) Copyright 2011 rockwell automation solutions gmbh, D-76227 Karlsruhe
# ************************************************************************
"""


import string
import types
import re
import tempfile
import os
import sys
import shutil

RE_DEVELOPMENTORDER = r"DO-\d{4,8}-\d{8,8}-\d{6,6}-[A-Z]{3,4}"

class Revision:
  def __init__ (self, revstr):
    self.revstr = revstr
    self.revDate = None
    self.computeRev ()

  def __repr__ (self):
    return self.revstr

  def __str__ (self):
    return self.__repr__ ()

  def setDate(self, dt):
    self.revDate = dt

  def getDate(self):
    return self.revDate

  def computeRev (self):
    rev = []
    for num in string.split (self.revstr, "."):
      rev.append (int (num))

    self.rev = rev

  def __cmp__(self, other):
    if (types.StringType==type (other)):
      other = Revision (other)
    cmpLeft = self.rev
    cmpRight = other.rev
	  
    if(self.getDate() and other.getDate()):
      cmpLeft = self.getDate()
      cmpRight = other.getDate()
	  
    if (cmpLeft == cmpRight): return 0
    if (cmpLeft < cmpRight): return -1
    if (cmpLeft > cmpRight): return 1

    raise "Exception on comparing revisions: (" + str(self) + ", " + str (other) + ")"

  # the current revision is a parent of the other revision,
  # when the other revision is a child of the current revision
  def isParentOf (self, other):
    if (types.StringType==type (other)):
      other = Revision (other)

    return other.isChildOf (self)


  def isChildOf (self, other):
    if (types.StringType==type (other)):
      other = Revision (other)

    childlength = len (self.rev)
    parentlength = len (other.rev)

    # precondition, the parent may not have more branches
    # than the child
    if (parentlength>childlength):
      return 0

    # only the last revision caption may differ
    # and only when it is not a branch
    for idx in range (0, parentlength):
      if (0==(idx%2) or idx+1<parentlength):
        if (other.rev[idx]!=self.rev[idx]):
          return 0
      else:
        if (other.rev[idx]>self.rev[idx]):
          return 0

    #success
    return 1

  def getParent (self):
    lastNum = self.rev [-1]

    if (2 == len (self.rev)) or (1 < lastNum):
      rev = self.rev [:-1] + [lastNum - 1]
    else:
      rev = self.rev [:-2]

    revList = []
    for num in rev:
      revList.append (str (num))

    return Revision (".".join (revList))

class CVSFile:
  def __init__ (self, loginfo, fromversion = None, toversion = None):
    #file.seek (0)
    self.log = loginfo
    if "" == self.log:
      raise "Log file was empty"
    self.attribs = {}
    self.tags = {}
    self.remarks = {}
    self.branches = {}
    self.stateDict = {}
    self.revDateDict = {}
    self.rcsfile = self.getValue ("RCS file")
    #self.rcsfile = self.getValue ("Working file")
    cvsroot = os.environ ["CVSROOT"]
    prefix = cvsroot[cvsroot.rfind(":")+1:]
    self.attribs ["Working file"] = self.rcsfile[len(prefix) + 1:-2]
    self.rcsfile = self.getValue ("head")
    #print self.attribs
    self.initRemarks ()
    self.initTags ()


  def getValue (self, name):
    findexpr = r"^%s:[ ]*(?P<value>.*?)$"
    obj = re.compile (findexpr % (name), re.MULTILINE).search (self.log)
    if None==obj:
      raise "Value of '" + str (name) + "' not found"
    else:
      value = obj.group ("value")
      self.attribs [name] = value
      return value

  def initTags (self):
    findexpr = r"(?P<begin>symbolic names:.*?\n)(?P<value>.*)(?P<end>\nkeyword substitution:.*?\n)"
    obj = re.compile (findexpr, re.MULTILINE|re.DOTALL).search (self.log)
    if None!=obj:
      for line in string.split (obj.group ("value"), "\n"):
        line = string.replace (line, " ", "")
        line = string.replace (line, "\t", "")
        line = string.split (line, ":")
        revStr = line[1]
        rev = Revision (revStr)
        rev.setDate(self.revDateDict.get(revStr))
        self.tags [line[0]] = rev
    else:
      print "No tag found for:", self.getValue ("RCS file")

  def initRemarks (self):
    end = len (self.log)
    COMMENTSTART = r"""
      (^-+\n
      ^revision\s+)(?P<revision>[\d\.]+)(\n)
      ^date:\s*(?P<date>[^;]*)(;\s*)
      author:\s*(?P<author>[^;]*)(;\s*)
      state:\s*(?P<state>[^;]*)(;[^\n]*\n)
      (^branches:\s*(?P<branches>[^\n]*)\n)?
    """

    FILEEND = r"(^=+$\s*\Z)" # a line, consists complete of = ands with whitespaces to end of string

    recommentstart = re.compile (COMMENTSTART, re.MULTILINE|re.DOTALL|re.VERBOSE)
    refileend = re.compile (FILEEND, re.MULTILINE|re.DOTALL|re.VERBOSE)

    try:
      found = recommentstart.search (self.log)
      while None != found:
        start = found.end ()
        rev = found.group ("revision")
        brans = found.group ("branches")
        state = found.group ("state")
		# date is yyyy/mm/dd HH:MM:SS, so a string can be used for comarision
        revDate = found.group ("date")
        if None != brans:
          self.branches [rev] = brans

        found = recommentstart.search (self.log, start)
        if None != found:
          end = found.start ()
        else:
          end = refileend.search (self.log, start).start ()

        self.stateDict[rev] = state
        self.remarks[rev] = self.log[start:end]
        self.revDateDict[rev] = revDate

    except:
      print "Exception on parsing remarks:", sys.exc_info()
      print self.log[start:]
      #print self.log

  #
  # check if the given tag is set on the latest revision checked in with this tag
  #
  def checkTag (self, tagname):
    revs = self.getRevisionsFromDO (tagname)

    try:
      if [] == revs:
        if tagname not in self.tags.keys():
          return 1
        else:
          return 0
      else:
        # first check deleted files
        state = self.stateDict [str(revs[-1])]
        if 'dead' == state:
          return tagname not in self.tags.keys()

        rev = self.tags [tagname]
        if rev in revs:
          for tmprev in revs:
            if tmprev>rev:
              return 0
          return 1
    except:
      return 0

    return 0

  #
  # returns revision changes for given tag
  #
  def getRevisionsFromDO (self, tagname):
    revs = []
    for revision in self.remarks.keys ():
      if 0 <= string.find (self.remarks[revision], tagname):
        rev = Revision(revision)
        rev.setDate(self.revDateDict.get(revision))
        revs.append (rev)

    revs.sort ()
    return revs


class CVSCommitLog:
  def __init__ (self, commitfile, filelist):
    self.commitinfo = commitfile.read ()

    files = string.split (filelist)
    self.directory = files[0]
    self.filelist = []
    for file in files[1:]:
      self.filelist.append (string.split(file, ','))

    REGEXP = r"""
      (\A.*?)
      (^Modified\sFiles:\s*(?P<modified>.*?))?
      (^Added\sFiles:\s*(?P<added>.*?))?
      (^Removed\sFiles:\s*(?P<removed>.*?))?
      (^Log\sMessage:\s*(?P<message>.*))?
      (\Z)
    """

    regexp = re.compile (REGEXP, re.VERBOSE|re.DOTALL|re.MULTILINE).match (self.commitinfo)

    print "Modified files:"
    self.modfiles = self.getFileList (regexp.group ("modified"))
    print self.modfiles
    print "Added files:"
    self.addedfiles = self.getFileList (regexp.group ("added"))
    print self.addedfiles
    print "Removed files:"
    self.removedfiles = self.getFileList (regexp.group ("removed"))
    print self.removedfiles
    print "Log message:"
    self.commitmessage = regexp.group ("message")
    print self.commitmessage

    print "Development order:"
    self.devorder = re.compile (RE_DEVELOPMENTORDER, re.VERBOSE|re.DOTALL|re.MULTILINE).search (self.commitmessage).group ()
    print self.devorder

  def getFileList (self, filelist):
    result = {}
    if None != filelist:
      branch = "HEAD"
      filelist = string.replace (filelist, "Tag: ", "Tag:")
      filelist = string.replace (filelist, "No tag", "Tag:" + branch)
      filelist = string.split (filelist)

      result[branch] = []
      for file in filelist:
        if "Tag:" == file[:4]:
          branch = file[4:]
          result [branch] = []
        else:
          result [branch].append (file)

    return result

  def tag (self):
    for file in self.filelist:
      if "NONE" != file[2]:
        tagcommand = "cvs -z9 rtag -F -r " + file[2] + " " + self.devorder + " " + self.directory + "/" + file[0]
        print tagcommand
        pipe = os.popen (tagcommand)
        if None != pipe.close ():
          raise "Error on tagging file"

def createFromFileName (filename):
  workdir = os.getcwd()
  #os.putenv ("CVSROOT", ":pserver:rainer@nick:/home/cvsroot")

  tmpdirname = tempfile.mktemp(".TMP")
  os.mkdir (tmpdirname)
  os.chdir (tmpdirname)

  """
  logfile = os.popen ("cvs -z9 co %s" % filename)
  loginfo = logfile.read ()
  errorcode = logfile.close ()
  if None != errorcode:
    raise "Error on checking out '" + filename + "'"
  """

  logfile = os.popen ("CVS -z9 rlog %s" % filename)
  loginfo = logfile.read ()
  errorcode = logfile.close ()
  if None != errorcode:
    raise "Error on retrieving loginfo for file '" + filename + "'"

  #print loginfo
  cvsfiles = []

  start = 0
  end = len (loginfo)
  FILEBEGIN = r"(?P<fbegin>\s*RCS\sfile:)"
  FILEEND = r"(^=+$)"
  ENDOFFILES = r"(\s*\Z)"
  regexpbegin = re.compile (FILEBEGIN, re.MULTILINE|re.VERBOSE)
  regexpendbegin = re.compile (FILEEND + FILEBEGIN, re.MULTILINE|re.VERBOSE)
  regexpend = re.compile (FILEEND + ENDOFFILES, re.MULTILINE|re.VERBOSE)
  found = regexpbegin.search (loginfo)
  while None != found:
    start = found.start ("fbegin")
    found = regexpendbegin.search (loginfo, start)
    if None != found:
      end = found.start ("fbegin")
    else:
      # throws exception if cannot find end
      end = regexpend.search (loginfo, start).end ()

    newfile = CVSFile (loginfo[start:end])
    cvsfiles.append (newfile)

  os.chdir (workdir)
  shutil.rmtree (tmpdirname)

  return cvsfiles


def checkDO (filename, tagname):
  errors = 0
  cvsfiles = createFromFileName (filename)

  directorygroup = None
  approveList = []
  approvedTag = os.environ.get("APPROVED_TAG")
  approvedRemark = ""
  if not approvedTag:
    approvedRemark = "rem APPROVED_TAG not defined in environment => "
    approvedTag = "%APPROVED_TAG%"

  print "\n---- committed files ----"

  for cvsfile in cvsfiles:
    filename = cvsfile.attribs["Working file"]
    lastslash = filename.rfind ("/")
    if -1 != lastslash:
      directory = filename[:lastslash+1].replace('/Attic', '')
      filename = filename [lastslash+1:]
    else:
      directory = "CVSROOT:"

    #print "Check:",cvsfile.attribs["Working file"]
    revs = cvsfile.getRevisionsFromDO (tagname)

    #print filename, revs

    if [] != revs:
      approveList.append("%scvs -z9 rtag -F -r %s %s \"%s\"" % (approvedRemark, revs [-1], approvedTag, cvsfile.attribs["Working file"]))
      state = cvsfile.stateDict [str(revs[-1])]
      if cvsfile.checkTag (tagname):
        revs.sort ()
        if directorygroup != directory:
          directorygroup = directory
          print
          print os.path.join ("/", os.path.dirname (directory))

        MAX_HEADREVISION = "1.1000000"

        revList = []
        checkOnlyHeadRev = revs [-1].isParentOf (MAX_HEADREVISION)
        revisionsOnBranch = False
        for rev in revs:
          if 'Exp' != state:
            revStr = "[%s --> %s]" % (rev.getParent (), {'dead': 'delete'}[state])
          else:
            revStr = "[%s]" % (rev,)

          if checkOnlyHeadRev:
            if rev.isParentOf (MAX_HEADREVISION):
              revList.append (revStr)
            else:
              revisionsOnBranch = True
          else:
            revList.append (revStr)

        outputStr = "   %s: %s" % (filename, string.join (revList, ' '))
        if revisionsOnBranch:
          outputStr += " (There are also lower revisions on branch)"

        print outputStr
        #print cvsfile.branches
        #print cvsfile.remarks
      else:
        revs.sort ()
        try:
          if 'dead' != state:
            print "cvs -z9 rtag -F -r %s %s %s" % (revs [-1], tagname, cvsfile.attribs["Working file"])
          else:
            print "cvs -z9 rtag -d -r %s %s %s" % (revs [-1], tagname, cvsfile.attribs["Working file"])

        except IndexError, exc:
          print "ERROR on file %s, eventually labeled without checkin text" % cvsfile.attribs["Working file"]

        errors = errors + 1

  print "\n---- end of file ----"

  print "\n---- DO approval commands ----\n"
  if approvedRemark:
    print "Hint for project development managers"
    print "set APPROVED_TAG=<tag name>"
    print "before executing checkDO will provide a usable list of commands"
    print "to move a tag to the revisions of the checked DO"
  for approveStmt in approveList:
    print approveStmt
  print "\n---- End of DO approval commands ----"

  if 0 < errors:
    print "There are %s errors, please correct them:" % errors


def containsDO (filename):
  file = open (filename)
  commitmessage = file.read ()
  file.close ()
  devorder = re.compile (RE_DEVELOPMENTORDER, re.VERBOSE|re.DOTALL|re.MULTILINE).search (commitmessage)

  if None == devorder:
    raise "Development order not found"
  else:
    print devorder.group ()

def checkMerge(fileIn):
  file = open(fileIn)
  lines = file.readlines()
  file.close()
  
  regExpNew = re.compile("File (.+) is new; .+ revision ([0-9.]+)")
  regExpChanged = re.compile("File (.+) changed from revision ([0-9.]+) to ([0-9.]+)")
  regExpRemoved = re.compile("File (.+) is removed; .+ revision ([0-9.]+)")
  branch = os.environ.get("BRANCH_TAG")
  if not branch:
    branch = "<BRANCH>"
  for line in lines:
    if not line:
	  continue
    if regExpNew.match(line):
      match = regExpNew.match(line)
      print "REM BRANCHING %s(%s): New file can be merged in by setting the branch" % (match.group(1), match.group(2))
      print "cvs rtag -b -r %s %s \"%s\"" % (match.group(2), branch, match.group(1))
    elif regExpChanged.match(line):
      match = regExpChanged.match(line)
      fileName = match.group(1)
      revLeft = Revision(match.group(2))
      revRight = Revision(match.group(3))
      if revLeft.isParentOf(revRight):
        print "REM BRANCHING %s: Modified file can be merged, by moving the branch from %s to %s" % (fileName, revLeft, revRight)
        print "cvs rtag -d -B %s \"%s\"" % (branch, fileName)
        print "cvs rtag -b -r %s %s \"%s\"" % (revRight, branch, fileName)
      elif revRight.isParentOf(revLeft):
        print "REM OK %s(%s): Modified file needs no merge, since only modified on branch where to integrate. Other revision %s" % (fileName, revLeft, revRight)
      else:
        print "REM MERGE %s(%s): Modified file needs merge. Other revision %s" % (fileName, revLeft, revRight)
    elif regExpRemoved.match(line):
      match = regExpRemoved.match(line)
      print "REM OK %s(%s) is only on the left branch." % (match.group(1), match.group(2))
    else:
      raise Exception ("'" + line + "' cannot be parsed")

if "__main__" ==__name__:
  action = sys.argv[1]
  if "check" == action:
    tagname = sys.argv[2]
    filename = string.join (sys.argv[3:], " ")
    checkDO (filename, tagname)
  elif "commitlog" == action:
    print sys.argv
    filelist = sys.argv[2]
    commitfiles = CVSCommitLog (sys.stdin, filelist)
    commitfiles.tag ()
    print commitfiles.directory
    for file in commitfiles.filelist:
      print file
  elif "containsdo" == action:
    filename = sys.argv[2]
    containsDO (filename)
  elif "do" == action:
    tagname = sys.argv[2]
    filename = string.join (sys.argv[3:], " ")
    files = createFromFileName(filename)
    for file in files:
      if tagname in file.tags:
        print file.attribs["Working file"], file.tags[tagname]
        #print "cvs rtag -F -r", file.tags[tagname], "FTPS_2_2_PFIZER_SXE01LS11P_V02_000_APPROVED", file.attribs["Working file"]
  elif "diff2merge" == action:
    # Pass a CVS diff result. E.g. from cvs -z9 rdiff -r FTPS_3_1_PFIZER_AMPS_K1USN00062_V01_1_2_B02 -r FTPS_3_1_PFIZER_AMPS_K1USN00062_BRANCH -s ftps > amps_112b02_12branch.txt
	# Left revision is the BRANCH into what you want to update. Right revision is the tag or label you want to merge into the left tag.
    fileIn = sys.argv[2]
    checkMerge(fileIn)
  else:
    raise Exception("Unknown command: " + action)