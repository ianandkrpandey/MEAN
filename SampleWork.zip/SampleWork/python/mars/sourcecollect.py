""" ************************************************************************
#  Description: walks over a given directory and collects all Java soruce files in a newly created subdirectory
#
#   $RCSfile: sourcecollect.py,v $
#    $Source: /var/cvs/ftps/ftps/tools/python/sourcecollect.py,v $
#      $Date: 2012/02/06 12:37:09 $
#    $Author: hplang $
#  $Revision: 1.1 $
#
#  (c) Copyright 2012 rockwell automation solutions gmbh, D-76227 Karlsruhe
# ************************************************************************
"""

import glob
import os
import os.path
import shutil
import string
import sys


_javaFileNames = []


def _processOptions(options):
  validOptions = []

  for option in options:
    if option not in validOptions:
      print "ERROR: Invalid option (%s)" % (option)
      _usage ()


def _usage():
  print ""
  print "Usage: sourcecollect[.py] <start directory>"
  sys.exit()


def _collect(startDirectory):
  dsxDirectories = []
  pathNames = [f[0] for f in [glob.glob(d[0]) for d in os.walk(startDirectory)] if f]
  for pathName in pathNames:
    if os.path.isdir(pathName):
      _collectJavaFileNames(os.path.abspath(pathName))
  _copyJavaFiles(startDirectory, _javaFileNames)


def _copyJavaFiles(startDirectory, javaFileNames):
  targetRoot = os.path.abspath('./_result')
  if not os.path.exists(targetRoot):
    os.makedirs(targetRoot)
  for item in javaFileNames:
    lines = open(item, 'r').readlines()
    for line in lines:
      if line[:8] == 'package ':
        packageName = string.split(line[8:], ';')[0]
        packagePath = packageName.replace('.', '/')
        targetPath = os.path.abspath(os.path.join(targetRoot, packagePath))
        if not os.path.exists(targetPath):
          os.makedirs(targetPath)
        targetPath = os.path.abspath(os.path.join(targetPath, os.path.split(item)[1]))
        shutil.copyfile(item, targetPath)


def _collectJavaFileNames(directory):
  global _javaFileNames
  javaFiles = glob.glob(os.path.join(directory, '*.java'))
  if javaFiles:
    _javaFileNames += javaFiles


if __name__ == '__main__':
  allOptions = []
  allArguments = []

  # process command line arguments, i.e. split them into options and parameter
  idx = 1
  while idx < len(sys.argv):
    if not string.find(sys.argv[idx], '-'):
      allOptions.append(sys.argv[idx])
    else:
      allArguments.append(sys.argv[idx])
    idx = idx + 1
  _processOptions (allOptions)

  _collect(allArguments[0])
  configurationReportLines = []
