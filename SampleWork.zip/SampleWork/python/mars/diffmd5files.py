""" ************************************************************************
#  Description: calculates the differences between to MD5 cehcksums files
#
#   $RCSfile: diffmd5files.py,v $
#    $Source: /var/cvs/ftps/ftps/tools/python/diffmd5files.py,v $
#      $Date: 2012/07/10 13:21:40 $
#    $Author: hplang $
#  $Revision: 1.4 $
#
#  (c) Copyright 2009 rockwell automation solutions gmbh, D-76227 Karlsruhe
# ************************************************************************
"""
vcsid = '$Header: /var/cvs/ftps/ftps/tools/python/diffmd5files.py,v 1.4 2012/07/10 13:21:40 hplang Exp $'


# standard module
import os
import re
import string
import shutil
import sys
import tempfile


# define some regular expressions
reFileString = '(?P<fileName>[\S ]+\S)\s+(?P<md5hash>\S+)\s*$'
reFile       = re.compile(reFileString)

# global constants
_createUpdate = None
_createImportList = None

# list of PD objects that are new compared to the standard but do not have a name with 'ct' prefix or something similar
_customObjectsWithoutProperPrefix = [
    'libraries\\neethi-2.0.4.jar.xml'
  , 'libraries\\xmlschema-1.4.3.jar.xml'
  , 'addon_jars\\commons-testdata.jar'
  , 'addon_jars\\neethi-2.0.4.jar'
  , 'addon_jars\\xmlschema-1.4.3.jar'
  ]


def _usage():
  print ""
  print "Usage: diffmd5files[.py]  <md5file1> <md5file2>"
  print "  <md5file1>: file name - result of 'checksums'"
  print "  <md5file2>: file name - result of 'checksums'"
  print "  writes (at most three) new files for the differences\n"
  print "\nUse 'diffmd5files[.py] -h' to get this message"
  sys.exit()


def _processOptions(options):
  validOptions = ['-h', '-u', '-i']

  for option in options:
    if option not in validOptions:
      print "ERROR: Invalid option (%s)" % (option)
      _usage ()

  if '-h' in options:
    _usage ()

  if '-u' in options:
    global _createUpdate
    _createUpdate = 1

  if '-i' in options:
    global _createImportList
    _createImportList = 1


def main(md5FileOne, md5FileTwo):
  md5DictOne    = {}
  md5DictTwo    = {}
  differentHash = []
  leftOnly      = []
  rightOnly     = []

  # collect all data in dictionaries
  contentOne = open(md5FileOne, 'r').readlines()
  for line in contentOne:
    res = reFile.match(line)
    if res:
      fileName = res.group('fileName')
      md5hash  = res.group('md5hash')
      md5DictOne[fileName] = md5hash
    else:
      print 'cannot parse line: ', line

  contentTwo = open(md5FileTwo, 'r').readlines()
  for line in contentTwo:
    res = reFile.match(line)
    if res:
      fileName = res.group('fileName')
      md5hash  = res.group('md5hash')
      md5DictTwo[fileName] = md5hash
    else:
      print 'cannot parse line: ', line

  # calculate the differences
  for key in md5DictOne.keys():
    if md5DictTwo.has_key(key):
      if md5DictOne[key] != md5DictTwo[key]:
        differentHash.append(key)
    else:
      leftOnly.append(key)
  for key in md5DictTwo.keys():
    if not md5DictOne.has_key(key):
      rightOnly.append(key)

  if differentHash:
    differentHash.sort()
    newDiffFile = open('md5diff.changed', 'w')
    for filename in differentHash:
      newDiffFile.write('%s\n' % filename)
    newDiffFile.close()

  if leftOnly:
    leftOnly.sort()
    newDiffFile = open('md5diff.leftonly', 'w')
    for filename in leftOnly:
      newDiffFile.write('%s\n' % filename)
    newDiffFile.close()

  if rightOnly:
    rightOnly.sort()
    newDiffFile = open('md5diff.rightonly', 'w')
    for filename in rightOnly:
      newDiffFile.write('%s\n' % filename)
    newDiffFile.close()


  if _createUpdate:
    tmpDirectoryName = tempfile.mktemp()
    os.mkdir(tmpDirectoryName)
    for filename in differentHash:
      head, tail = os.path.split(filename)
      fullHead = os.path.join(tmpDirectoryName, head)
      if not os.path.exists(fullHead):
        os.makedirs(fullHead)
      shutil.copy(os.path.abspath(os.path.join('.', filename)), fullHead)
    for filename in rightOnly:
      head, tail = os.path.split(filename)
      fullHead = os.path.join(tmpDirectoryName, head)
      if not os.path.exists(fullHead):
        os.makedirs(fullHead)
      shutil.copy(os.path.abspath(os.path.join('.', filename)), fullHead)
    updateDir = os.path.join('.', 'appconf.md5.update')
    shutil.copytree(tmpDirectoryName, updateDir)

  if _createImportList:
    # first join the different and right only files
    allDifferences = differentHash[:]
    for item in rightOnly:
      if item not in allDifferences:
        allDifferences.append(item)
    allDifferences.sort()

    importStandardObjectsFile = open('import_standard_objects.txt', 'w')
    for item in allDifferences:
      if not _isCustomerSpecific(item):
        importStandardObjectsFile.write('%s\n' % item)
    importStandardObjectsFile.close()

    importCustomObjectsFile = open('import_custom_objects.txt', 'w')
    for item in allDifferences:
      if _isCustomerSpecific(item):
        importCustomObjectsFile.write('%s\n' % item)
    importCustomObjectsFile.close()


def _isCustomerSpecific(fileNameWithParentDirectory):
  head, tail = os.path.split(fileNameWithParentDirectory)
  fileName = tail.lower()
  return (fileName[:3] == 'ct_' or fileName[:3] == 'ct-' or fileName[:4] == '_ct_' or fileName[:4] == '_ct-' or '_ct_' in fileName
          or fileNameWithParentDirectory in _customObjectsWithoutProperPrefix)


if __name__ == '__main__':
  allOptions = []
  allArguments = []

  # process command line arguments, i.e. split them into options and parameter
  idx = 1
  while idx < len(sys.argv):
    if not string.find(sys.argv[idx], '-'):
      allOptions.append(sys.argv[idx])
    else:
      allArguments.append(sys.argv[idx])
    idx = idx + 1

  _processOptions (allOptions)

  if (len(allArguments) not in [2,3]):
    print ""
    print "ERROR: wrong number of parameters (not 2)"
    _usage ()

  if _createUpdate:
    sys.argv = sys.argv[1:]

  main(allArguments[0], allArguments[1])
