""" ************************************************************************
#  Description: checks the project specific help files as specified in the message
#               packs 'OnlineHelpLinkage_ct_xxx' and 'OnlineHelpLinkage_ucct_xxx'
#              against the archived help files
#
#   $RCSfile: checkhelpfiles.py,v $
#    $Source: /var/cvs/ftps/ftps/tools/python/checkhelpfiles.py,v $
#      $Date: 2010/10/14 17:11:10 $
#    $Author: RWeinga $
#  $Revision: 1.2 $
#
#  (c) Copyright 2009 rockwell automation solutions gmbh, D-76227 Karlsruhe
# ************************************************************************
"""
vcsid = '$Header: /var/cvs/ftps/ftps/tools/python/checkhelpfiles.py,v 1.2 2010/10/14 17:11:10 RWeinga Exp $'


import glob
import os
import re
import string
import sys
import re


reMessageString = '<message>(?P<fileName>[\S ]+?)</message>'
reMessage       = re.compile(reMessageString, re.DOTALL)


def _usage():
  print ""
  print "Usage: checkhelpfiles[.py] <message packs directory> <help files directory>"
  print "  <message packs directory>: the directory in the filesystem where the disassembled DSX files for message packs are"
  print "     <help files directory>: the directory in the filesystem where the help files are"
  print "  compares the project specific help files as specific in message packs against the archived help files."
  sys.exit()


def main(msgPackDir, helpFileDir):
  fileNamesFromMessagePack = _allFileNamesFromMessagePacks(msgPackDir)
  fileNamesOfHelpFiles     = _allFileNamesOfHelpFiles(helpFileDir)
  _reportMissingHelpFiles(fileNamesFromMessagePack, fileNamesOfHelpFiles)


def _allFileNamesFromMessagePacks(msgPackDir):
  workFlows = glob.glob(os.path.abspath(msgPackDir) + '/OnlineHelpLinkage_ct_*.xml')
  useCases = glob.glob(os.path.abspath(msgPackDir) + '/OnlineHelpLinkage_ucct_*.xml')

  fileNames = []
  for workFlow in workFlows + useCases:
    workFlowFile = open(workFlow, 'r')
    matches = re.findall(reMessage, workFlowFile.read())
    for hit in matches:
      dir, fileName = hit.split('/')
      if hit not in fileNames and fileName[:3] == 'ct_':
        fileNames.append(hit)
    workFlowFile.close()

  fileNames.sort()
  return fileNames


def _allFileNamesOfHelpFiles(helpFileDir):
  helpFiles = glob.glob(os.path.abspath(helpFileDir) + '/*/*.htm')

  fileNames = []
  for fileName in helpFiles:
    head, fileNameOnly = os.path.split(fileName)
    head, fileNameDir = os.path.split(head)
    simpleFileName = fileNameDir + '/' + fileNameOnly
    if simpleFileName not in fileNames:
      fileNames.append(simpleFileName)

  fileNames.sort()
  return fileNames


def _reportMissingHelpFiles(fileNamesFromMessagePack, fileNamesOfHelpFiles):
  missingHelpFiles = []
  for item in fileNamesFromMessagePack:
    if item not in fileNamesOfHelpFiles:
      missingHelpFiles.append(item)

  if missingHelpFiles:
    print 'The following customer specific help files are configured in message packs but not archived:'
    for item in missingHelpFiles:
      print '  ',  item
  else:
    print 'All customer specific help files configured in message packs are archived.'


if __name__ == '__main__':
  allArguments = []

  # process command line arguments, i.e. split them into options and parameter
  idx = 1
  while idx < len(sys.argv):
    allArguments.append(sys.argv[idx])
    idx = idx + 1

  if len(allArguments) != 2:
    _usage()
  else:
    main(allArguments[0], allArguments[1])
