""" ************************************************************************
#  Project:     PMX
#  Description: parse the output of a 'cvs rdiff' call and write separate files for new, removed and changed files
#  Created:     24.06.2003
#
#   $RCSfile: filtercvsrdiff.py,v $
#    $Source: /var/cvs/ftps/ftps/tools/python/filtercvsrdiff.py,v $
#      $Date: 2012/02/23 19:04:36 $
#    $Author: hplang $
#  $Revision: 1.2 $
#
#  (c) Copyright 2003 propack data GmbH,
#      D-76131 Karlsruhe
# ************************************************************************
"""


# standard module
import os.path
import re
import string
import sys


# define some regular expressions for new, removed and changed files
reNewString     = 'File (?P<fileName>[\S ]+?) is new; \S+ revision (?P<currentRevision>[.\d]+)'
reNew           = re.compile(reNewString)
reRemovedString = 'File (?P<fileName>[\S ]+?) is removed; .*'
reRemoved       = re.compile(reRemovedString)
reChangedString = 'File (?P<fileName>[\S ]+?) changed from revision (?P<fromRevision>[.\d]+?) to (?P<toRevision>[.\d]+)'
reChanged       = re.compile(reChangedString)


def _usage():
  print ""
  print "Usage: filtercvsrdiff[.py]  <diff-file>"
  print "  <diff-file>: file name - result of a 'cvs rdiff between two labels/branches'\n"
  print "  writes 3 new files for new, removed and changed files'\n"
  print "\nUse 'filtercvsrdiff[.py] -h' to get this message"
  sys.exit()


def _processOptions(options):
  validOptions = ['-h',]

  for option in options:
    if option not in validOptions:
      print "ERROR: Invalid option (%s)" % (option)
      _usage ()

  if '-h' in options:
    _usage ()


def _sortByFirstArgument(left, right):
  if (left[0] < right[0]):
    return -1
  elif (left[0] > right[0]):
    return 1
  else:
    return 0


def main(diffFile):

  newDiffList     = []
  removedDiffList = []
  changedDiffList = []

  content = open(diffFile, 'r').readlines()
  for line in content:
    fileName = ''
    res = reNew.match(line)
    if res:
      fileName, currentRevision = res.group('fileName'), res.group('currentRevision')
      newDiffList.append([fileName, currentRevision])

    res = reRemoved.match(line)
    if res:
      fileName = res.group('fileName')
      removedDiffList.append(fileName)

    res = reChanged.match(line)
    if res:
      fileName, fromRevision, toRevision = res.group('fileName'), res.group('fromRevision'), res.group('toRevision')
      changedDiffList.append([fileName, fromRevision, toRevision])

    if not fileName:
      print "ERROR: couldn't parse line: %s" % line
      sys.exit()

  if newDiffList:
    newDiffList.sort(_sortByFirstArgument)
    maxNewFileName = max(map(lambda x: len(x[0]), newDiffList))
    newDiffFile = open(diffFile + '.new',     'w')
    for item in newDiffList:
      fileName, currentRevision = item
      newDiffFile.write('%s%s\t%s\n' % (fileName, ' ' * (maxNewFileName - len(fileName)), currentRevision))
    newDiffFile.close()

  if removedDiffList:
    removedDiffList.sort()
    maxRemovedFileName = max(map(lambda x: len(x), removedDiffList))
    removedDiffFile = open(diffFile + '.removed', 'w')
    for item in removedDiffList:
      removedDiffFile.write('%s\n' % item)
    removedDiffFile.close()

  if changedDiffList:
    changedDiffList.sort(_sortByFirstArgument)
    maxChangedFileName = max(map(lambda x: len(x[0]), changedDiffList))
    maxFromRevisionName = max(map(lambda x: len(x[1]), changedDiffList))
    changedDiffFile = open(diffFile + '.changed', 'w')
    for item in changedDiffList:
      fileName, fromRevision, toRevision = item
      changedDiffFile.write('%s%s\t%s%s --> %s\n' % (fileName, ' ' * (maxChangedFileName - len(fileName)),
          fromRevision, ' ' * (maxFromRevisionName - len(fromRevision)), toRevision))
    changedDiffFile.close()


if __name__ == '__main__':
  allOptions = []
  allArguments = []

  # process command line arguments, i.e. split them into options and parameter
  idx = 1
  while idx < len(sys.argv):
    if not string.find(sys.argv[idx], '-'):
      allOptions.append(sys.argv[idx])
    else:
      allArguments.append(sys.argv[idx])
    idx = idx + 1

  _processOptions (allOptions)

  if (1 != len(allArguments)):
    print ""
    print "ERROR: wrong number of parameters (not 1)"
    _usage ()

  main(sys.argv[1])
