""" ************************************************************************
#  Description: calculation of MD5 checksums for DSX files - needs Python 2.6
#
#   $RCSfile: checksums.py,v $
#    $Source: /var/cvs/ftps/ftps/tools/python/checksums.py,v $
#      $Date: 2013/06/05 13:19:12 $
#    $Author: spunzman $
#  $Revision: 1.21 $
#
#  (c) Copyright 2009 rockwell automation solutions gmbh, D-76227 Karlsruhe
# ************************************************************************
"""
vcsid = '$Header: /var/cvs/ftps/ftps/tools/python/checksums.py,v 1.21 2013/06/05 13:19:12 spunzman Exp $'


from hashlib import md5
import StringIO
import codecs
import glob
import os
import os.path
import string
import sys
import uu
import xml.etree.ElementTree as ET
import diffmd5files
import re

_sortAttributs       = ['name']
_sortElements        = ['./name', './message-id']
_nullAttributs       = ['UPDATE-PRIVILEGE-KEY', 'LAST-MODIFIER-KEY', 'OBJECT-SOURCE', 'CREATOR-KEY', 'SITE-NUMBER', 'KEY', 'DELETE-PRIVILEGE-KEY',
                        'MODIFICATION-FLAG', 'MODIFICATION-KEY', 'TYPE', 'SITE-NUMBER', 'OWNER-KEY', 'OWNER-TYPE', 'DSX-TOOL-MODIFIED', 'BLOB-KEY',
                        'AT-COLUMN-DEFINITIONS-CHANGED', 'AT-INDEX-DEFINITIONS-CHANGED', 'PERFORMER-OR-VERIFIER-KEYS-CHANGED', 'ITEMS-CHANGED'
                      ]

_nullAttributsPerTag = {  'DADDON' : ['MESSAGE-PACK-KEY']
                        , 'DACTIVITYSET' : ['MESSAGE-PACK-KEY']}
_allNullAttributesCache = {}
_nullElements        = ['LAST-MODIFIED-TIME', 'ACCESS-CONTROL-INFO', 'CREATION-TIME']
_nullDirectories     = ['CVS', ]
_tmpFileExtension    = '.tmp'
_doCleanup           = 0
_doIgnoreWhitespace  = 0
_doCalculateDifference = 0
_prettyTypeNames = {
  'accessprivilege'      : 'Access Privilege',
  'activities'           : 'Activity',
  'activityset'          : 'Activity Set',
  'application'          : 'Application',
  'atdefinition'         : 'AT Definition',
  'datacollectionset'    : 'Datcollection Set',
  'datadictionaryclass'  : 'Data Dictionary Class',
  'deanzaform'           : 'Form',
  'dsimage'              : 'Image',
  'dsmessages'           : 'Message Pack',
  'eventsheetholder'     : 'Event Sheet',
  'flexiblestatemodel'   : 'Flexible State Model',
  'libraries'            : 'Library',
  'locale'               : 'Locale',
  'reportdatadefinition' : 'Report Data Definition',
  'reportdesign'         : 'Report Design',
  'semanticpropertyset'  : 'Semantic Property Set',
  'subroutine'           : 'Subroutine',
  'user'                 : 'User',
  'usergroup'            : 'User Group',
  'udadefinition'        : 'UDA Definition',
  'fsmconfiguration'     : 'FSM Configuration',
  'dslist'               : 'List',
  }
_prettyTypeNamesFromKey = {
  '101' : 'Label Designs',
  '117' : 'Report Designs',
  '123' : 'Activity Sets',
  '13'  : 'Forms',
  '147' : 'Libraries',
  '38'  : 'Stations',
  }
_prettyTypeNamesForInstallation = {
  'accessprivilege'       : 'accessprivilege',
  'activities'            : 'addon',
  'activityset'           : 'activityset',
  'application'           : 'application',
  'atdefinition'          : 'atdefinition',
  'datacollectionset'     : 'dcsdefinition',
  'datadictionaryclass'   : 'datadictionaryclass',
  'deanzaform'            : 'form',
  'dsimage'               : 'generic',
  'dslist'                : 'list',
  'dsmessages'            : 'messagepack',
  'eventsheetholder'      : 'form',
  'flexiblestatemodel'    : 'flexiblestatemodel',
  'fsmconfiguration'      : 'fsmconfiguration',
  'libraries'             : 'addon',
  'locale'                : 'locale',
  'reportdatadefinition'  : 'reportdatadefinition',
  'reportdesign'          : 'reportdesign',
  'semanticpropertyset'   : 'semanticpropertyset',
  'subroutine'            : 'library',
  'udadefinition'         : 'udadefinition',
  'user'                  : 'user',
  'usergroup'             : 'usergroup',
  }

_installFileHeader = """# The files mentioned here are allowed to be imported by the installer. each line must hold one object name
# where the object name adheres to the format <class simple name without leading 'D'>-<object name> all
# lowercase. the class simple name is the one from the Java package com.datasweep.plantops.common.dataobjects.
# Lines starting with '#' are ignored.
#
# If there are no valid lines the content of the file is ignored and everything is imported. The same is true
# if there is no file named allowed_objects.txt in the cmd subdirectory of the installer.
#
# Examples for object names:
#
# application-ct_application
# list-ct_startableactivitysetnames
# library-ct_commons

"""


def extractConfiguration(startDirectory):
  """ expects to be started at the root directory of all DSX files 'configuration\dsx'
  """
  configuration = []
  reportLines = []
  dsxApplicationsDirectory = _getDsxApplicationsDirectory(startDirectory)
  dsxFiles = _getAllDsxFiles(dsxApplicationsDirectory)
  if dsxFiles:
    for dsxFile in dsxFiles:
      parameters = extractParametersForXml(dsxFile)
      nestedParameters = extractNestedParametersForXml(dsxFile)

      for key, value in parameters:
        configuration.append([_shortAbsoluteFileName(dsxFile), key, value])
      maxNestedTypeSize = 10
      if nestedParameters:
        maxNestedTypeSize = max([len(type) for type, key, value in nestedParameters])
      for type, key, value in nestedParameters:
        configuration.append([_shortAbsoluteFileName(dsxFile), type + ' '*(maxNestedTypeSize - len(type)) + ' - ' + key, value])

    configuration.sort(_compareCaseInsensitive)

    if configuration:
      maxKeySize = max([len(key) for dsxFile, key, value in configuration])
      currentDsxFile = None
      for dsxFile, key, value in configuration:
        if currentDsxFile != dsxFile:
          if currentDsxFile:
            reportLines.append('\n')
          reportLines.append('-' * 70 + '\n')
          reportLines.append('%s\n' % dsxFile)
          reportLines.append('%s\n\n' % ('-'*70))
          currentDsxFile = dsxFile
        reportLines.append('%s: %s\n' % (key + ' '*(maxKeySize - len(key)), value))
  return reportLines


def extractUsers(startDirectory):
  userGroupNames = extractUserGroupNamesForXml(startDirectory)
  userGroupNames.sort(_compareStringCaseInsensitive)

  configuration = []
  reportLines = []
  dsxApplicationsDirectory = _getDsxUsersDirectory(startDirectory)
  dsxFiles = _getAllDsxFiles(dsxApplicationsDirectory)
  if dsxFiles:
    for dsxFile in dsxFiles:
      userName, userGroups = extractUserGroupsForXml(dsxFile)
      configuration.append([_shortAbsoluteFileName(dsxFile), userName, userGroups])
    configuration.sort(_compareCaseInsensitive)


    reportLines.append('-' * 70 + '\n')
    reportLines.append('Groups\n')
    reportLines.append('-' * 70 + '\n\n')
    for item in userGroupNames:
      reportLines.append('%s\n' % item)
    reportLines.append('\n')

    maxKeySize = max([len(userName) for dsxFile, userName, userGroups in configuration])
    reportLines.append('-' * 70 + '\n')
    reportLines.append('Users %s Groups\n' % (' ' * (maxKeySize + 2)))
    reportLines.append('-' * 70 + '\n\n')

    currentUserName = None
    for dsxFile, userName, userGroups in configuration:
      firstOne = 1
      userGroups.sort(_compareStringCaseInsensitive)
      for group in userGroups:
        if firstOne:
          firstOne = 0
          reportLines.append('%s %s - %s\n' % (userName, ' '* (maxKeySize + 5 - len(userName)), group))
        else:
          reportLines.append('%s%s\n' % (' '* (maxKeySize + 9), group))

  return reportLines


def extractAccessRights(startDirectory):
  configuration = []
  reportLines = []
  dsxApplicationsDirectory = _getDsxAccessPrivilegesDirectory(startDirectory)
  dsxFiles = _getAllDsxFiles(dsxApplicationsDirectory)
  if dsxFiles:
    for dsxFile in dsxFiles:
      accessPrivilegeName, performers = extractAccessPrivilegesPerformersForXml(dsxFile)
      configuration.append([accessPrivilegeName, performers])


    maxKeySize = max([len(name) for name, performers in configuration])
    reportLines.append('-' * 100 + '\n')
    reportLines.append('Access Privileges %s Groups\n' % (' ' * (maxKeySize - 10)))
    reportLines.append('-' * 100 + '\n\n')

    currentUserName = None
    for name, performers in configuration:
      firstOne = 1
      performers.sort(_compareStringCaseInsensitive)
      for performer in performers:
        if firstOne:
          firstOne = 0
          reportLines.append('%s %s - %s\n' % (name, ' '* (maxKeySize + 5 - len(name)), performer))
        else:
          reportLines.append('%s%s\n' % (' '* (maxKeySize + 9), performer))

  return reportLines


def calculateObjectDifferenceToStandard(startDirectory, forInstallation = None):
  reportLines    = []
  changedObjects = []
  newObjects     = []

  projectPropertiesFileName = os.path.join(startDirectory, 'project.properties')
  if os.path.exists(projectPropertiesFileName):
    projectPropertiesFile = open(projectPropertiesFileName, 'r')
    properties = projectPropertiesFile.readlines()
    projectPropertiesFile.close()
    ftpsStandardFile = None
    currentFile      = None
    for line in properties:
      if line[:len('previousMd5File')] == 'previousMd5File':
        ftpsStandardFile = string.split(line, '=')[1].strip()
      if line[:len('md5File')] == 'md5File':
        currentFile = string.split(line, '=')[1].strip()

    if ftpsStandardFile and currentFile:
      ftpsStandardFile = os.path.join(startDirectory, ftpsStandardFile)
      currentFile = os.path.join(startDirectory, currentFile)
      diffmd5files.main(ftpsStandardFile, currentFile)

      md5diffChangedFile = os.path.join(startDirectory, 'md5diff.changed')
      md5diffRightOnlyFile = os.path.join(startDirectory, 'md5diff.rightonly ')

      if os.path.exists(md5diffChangedFile):
        md5diffChanged = open(md5diffChangedFile, 'r')
        content = md5diffChanged.readlines()
        md5diffChanged.close()
        for line in content:
          rootdir, atrowDir, type, name = '', '', '', ''
          if line[:3] == 'uc\\': # ignore use cases
            continue
          if line[:10] == 'dsx\\atrow\\': # ignore AT Rows
            rootdir, type, obsoleteAtRowType, name = string.split(line, '\\')
            if name[0] == '_':
              name = '{' + name[1:]
            if name[-6:-5] == '_':
              name = name.replace('_', '}')
          else:
            rootdir, type, name = string.split(line, '\\')
          if forInstallation:
            type = _prettyTypeNamesForInstallation.get(type, type)
          else:
            type = _prettyTypeNames.get(type, type)
          name = os.path.splitext(name)[0]
          changedObjects.append([type, name])

      if os.path.exists(md5diffRightOnlyFile):
        md5diffRightonly = open(md5diffRightOnlyFile, 'r')
        content = md5diffRightonly.readlines()
        md5diffRightonly.close()
        for line in content:
          rootdir, atrowDir, type, name = '', '', '', ''
          if line[:3] == 'uc\\': # ignore use cases
            continue
          if line[:10] == 'dsx\\atrow\\': # ignore AT Rows
            rootdir, type, obsoleteAtRowType, name = string.split(line, '\\')
            if name[0] == '_':
              name = '{' + name[1:]
            if name[-6:-5] == '_':
              name = name.replace('_', '}')
          else:
            rootdir, type, name = string.split(line, '\\')
          if forInstallation:
            type = _prettyTypeNamesForInstallation.get(type, type)
          else:
            type = _prettyTypeNames.get(type, type)
          name = os.path.splitext(name)[0]
          newObjects.append([type, name])

    if not forInstallation:
      reportLines.append('-' * 70 + '\n')
      reportLines.append('Modified Objects (compared TO FTPS standard)\n')
      reportLines.append('-' * 70 + '\n\n')
    changedObjects.sort(_compareFirstStringCaseInsensitive)
    changedObjects = [item for item in changedObjects if item[0] != 'addon_jars']
    maxKeySize = 0
    if changedObjects:
      maxKeySize = max([len(type) for type, name in changedObjects])
    currentType = None
    for type, name in changedObjects:
      if forInstallation:
        reportLines.append('%s-%s' % (type, name))
      else:
        if currentType != type:
          reportLines.append('%s  %s - %s\n' % (type, ' '*(maxKeySize - len(type)), name))
        else:
          reportLines.append('%s  %s\n' % (' '*(maxKeySize + 3), name))
        currentType = type

    if not forInstallation:
      reportLines.append('\n')
      reportLines.append('-' * 70 + '\n')
      reportLines.append('New Objects (compared TO FTPS standard)\n')
      reportLines.append('-' * 70 + '\n\n')
    newObjects.sort(_compareFirstStringCaseInsensitive)
    newObjects = [item for item in newObjects if item[0] != 'addon_jars']

    maxKeySize = 0
    if newObjects:
      maxKeySize = max([len(type) for type, name in newObjects])
    currentType = None
    for type, name in newObjects:
      if forInstallation:
        reportLines.append('%s-%s' % (type, name))
      else:
        if currentType != type:
          reportLines.append('%s  %s - %s\n' % (type, ' '*(maxKeySize - len(type)), name))
        else:
          reportLines.append('%s  %s\n' % (' '*(maxKeySize + 3), name))
        currentType = type

  return reportLines


def createChecksums(startDirectory):
  """ expects to be started at the root directory of all configuration files 'configuration'
  """
  checksums = []

  dsxDirectories = _getAllDsxDirectories(startDirectory)
  for directory in dsxDirectories:
    dsxFiles = _getAllDsxFiles(directory)
    if dsxFiles:
      for dsxFile in dsxFiles:
        checksum = None
        root, ext = os.path.splitext(dsxFile)
        print '  parsing ', _shortenedAbsoluteFileName(dsxFile.lower())
        if ext.upper() == '.XML':
          checksum = calculateChecksumForXml(dsxFile)
        elif ext.upper() == '.JAR':
          checksum = calculateChecksumForJar(dsxFile)

        if checksum:
          absStartDirectoryLower = os.path.abspath(startDirectory).lower()
          absDsxFileLower = dsxFile.lower()
          fileName = absDsxFileLower[len(absStartDirectoryLower) + 1:]
          checksums.append([fileName, checksum])

  if checksums:
    checksums.sort()
    checksumsFile = open('digest.md5', 'w')
    maxFileNameSize = max([len(file) for file, checksum in checksums])
    for file, checksum in checksums:
      checksumsFile.write('%s    %s\n' % (file.lower() + ' '*(maxFileNameSize - len(file)), checksum))
    checksumsFile.close()

  if _doCleanup:
    _cleanupTemporaryFiles(startDirectory)
  print 'done'


def _cleanupTemporaryFiles(startDirectory):
  print '  cleaning up temporary files'
  dsxDirectories = _getAllDsxDirectories(startDirectory)
  for directory in dsxDirectories:
    fileNames = glob.glob(directory + '/*' + _tmpFileExtension)
    for fileName in fileNames:
      os.remove(fileName)


def _getAllDsxDirectories(startDirectory):
  dsxDirectories = []
  pathNames = [f[0] for f in [glob.glob(d[0]) for d in os.walk(startDirectory)] if f]
  pathNames = [item.upper() for item in pathNames if item.upper() not in _nullDirectories]
  for pathName in pathNames:
    if os.path.isdir(pathName):
      dsxDirectories.append(os.path.abspath(pathName))
  return dsxDirectories


def _getDsxApplicationsDirectory(startDirectory):
  return os.path.abspath(os.path.join(startDirectory, 'dsx/Application'))


def _getDsxUsersDirectory(startDirectory):
  return os.path.abspath(os.path.join(startDirectory, 'dsx/User'))


def _getDsxAccessPrivilegesDirectory(startDirectory):
  return os.path.abspath(os.path.join(startDirectory, 'dsx/AccessPrivilege'))


def _getDsxUserGroupsDirectory(startDirectory):
  return os.path.abspath(os.path.join(startDirectory, 'dsx/UserGroup'))


def _getAllDsxFiles(directory):
  dsxFiles = []
  fileNames = glob.glob(directory + '/*.xml')
  fileNames = [item.upper() for item in fileNames]
  for fileName in fileNames:
    if os.path.isfile(os.path.join(directory, fileName)):
      dsxFiles.append(os.path.join(directory, fileName))
  fileNames = glob.glob(directory + '/*.jar')
  fileNames = [item.upper() for item in fileNames]
  for fileName in fileNames:
    if os.path.isfile(os.path.join(directory, fileName)):
      dsxFiles.append(os.path.join(directory, fileName))
  return dsxFiles


def calculateChecksumForXml(dsxFileName):
  content = _parseXml(dsxFileName)
  md5Hash = md5()
  if isinstance(content, unicode):
    content = content.encode("UTF-8")
  md5Hash.update(content)
  md5Digest = md5Hash.hexdigest()
  return md5Digest


def calculateChecksumForJar(dsxFileName):
  uuFileName = dsxFileName + _tmpFileExtension
  uu.encode(dsxFileName, uuFileName)
  uuFile = open(uuFileName, 'r')
  content = uuFile.read()
  uuFile.close()
  md5Hash = md5()
  md5Hash.update(content)
  md5Digest = md5Hash.hexdigest()
  return md5Digest


def extractParametersForXml(dsxFileName):
  parameters = []
  tree = ET.parse(dsxFileName)
  root = tree.getroot()
  properties = root.findall('DConfigurationProperties')
  defaultValue = ''
  for property in properties:
    name = property.find('name')
    value = property.find('value')
    if value != None:
      parameters.append([name.text, value.text])
    else:
      parameters.append([name.text, defaultValue])

  return parameters


def extractNestedParametersForXml(dsxFileName):
  parameters = []
  tree = ET.parse(dsxFileName)
  root = tree.getroot()
  items = root.findall('DApplicationItems')
  for item in items:
    properties = item.findall('DConfigurationProperties')

    defaultValue = ''
    for property in properties:
      name = property.find('name')
      value = property.find('value')
      if value != None:
        parameters.append([_prettyTypeNamesFromKey.get(item.attrib['object-type'], item.attrib['object-type']), name.text, value.text])
      else:
        parameters.append([_prettyTypeNamesFromKey.get(item.attrib['object-type'], item.attrib['object-type']), name.text, defaultValue])

  return parameters


def extractUserGroupNamesForXml(startDirectory):
  userGroups = []
  dsxApplicationsDirectory = _getDsxUserGroupsDirectory(startDirectory)
  dsxFiles = _getAllDsxFiles(dsxApplicationsDirectory)
  if dsxFiles:
    for dsxFile in dsxFiles:
      tree = ET.parse(dsxFile)
      root = tree.getroot()
      name = root.findall('name')[0]
      groupName = name.text
      userGroups.append(groupName)
  return userGroups


def extractAccessPrivilegesPerformersForXml(dsxFile):
  performers = []

  tree = ET.parse(dsxFile)
  root = tree.getroot()
  accessPrivilegeName = root.findall('name')[0]
  accessPrivilegeName = accessPrivilegeName.text

  elements = root.findall('performer-keys')
  for item in elements:
    performers.append(string.split(item.text, '-')[1])

  performers.sort(_compareStringCaseInsensitive)
  return accessPrivilegeName, performers


def extractUserGroupsForXml(dsxFileName):
  userGroups = []
  tree = ET.parse(dsxFileName)
  root = tree.getroot()

  name = root.findall('name')[0]
  userName = name.text

  properties = root.findall('user-group-users')
  defaultValue = ''
  for property in properties:
    value = property.attrib['group-key']
    if value != None:
      value = string.split(value, '-')[1]
      userGroups.append(value)

  userGroups.sort()
  return userName, userGroups


def _parseXml(dsxFileName):
  tree = ET.parse(dsxFileName)
  root = tree.getroot()

  output = []
  _printAttributsSorted(root, -4, output)
  _printChildrenSorted(root, 0, output)

  if _doIgnoreWhitespace:
    output = [string.strip(line, '\r') for line in output]
    output = [string.strip(line, '\n') for line in output]
    output = [line for line in output if string.strip(line)]

  fileName = dsxFileName + _tmpFileExtension
  result = codecs.open(fileName, 'w', 'UTF-8')
  for line in output:
    if isinstance(line, str):
      line = line.decode("UTF-8")
    result.write(line)
    result.write('\n')
  result.close()

  content = string.join(output, '\n')
  return content


def _printChildrenSorted(element, depth, output):
  #if element.tag == "DActivitySet":
  #  import pywin.debugger
  #  pywin.debugger.brk()
  childrenSorted = list(element.getchildren())
  childrenSorted.sort(lambda left, right: _cmpElement(left, right))
  depth += 4
  for child in childrenSorted:
    if child.tag.upper() in _nullElements:
      # skip these
      continue
    _printAttributsSorted(child, depth, output)
    _printChildrenSorted(child, depth, output)

def _cmpElement(left, right):
  # sort by tag name
  result = cmp(left.tag, right.tag)
  if(result != 0):
    return result

  # sort by prefered attribute names. E.g. name="einName"
  for attribName in _sortAttributs:
    result = cmp(left.get(attribName), right.get(attribName))
    if(result != 0):
      return result

  # sort by child tag texts. E.g. <name>einName</name>
  for tag in _sortElements:
    leftChild = left.find(tag)
    rightChild = right.find(tag)
    if leftChild == None or rightChild == None:
      continue
    result = cmp(leftChild.text, rightChild.text)
    if(result != 0):
      return result

  # sort by attribute values, but with ascending keys
  keys = set(left.keys())
  keys.update(right.keys())
  keys = list(keys)
  keys.sort()

  for key in keys:
    if key.upper() in _getAllNullAttributes(left):
      continue
    result = cmp(left.get(key), right.get(key))
    if(result != 0):
      return result

  leftText = left.text or ""
  rightText = right.text or ""

  if _doIgnoreWhitespace:
    leftText = leftText.strip()
    rightText = rightText.strip()

  # we don't know, try the texts in the end
  return cmp(leftText, rightText)

def _getAllNullAttributes(element):
  name = element.tag.upper()
  all = _allNullAttributesCache.get(name)
  if not all:
    all = list(_nullAttributs)
    if _nullAttributsPerTag.has_key(name):
      all.extend(_nullAttributsPerTag[name])
    _allNullAttributesCache[name] = all
  return all

def _printAttributsSorted(element, depth, output):
  keys = element.keys()
  keys.sort()
  keys = [item for item in keys if item.upper() not in _getAllNullAttributes(element)]
  if depth > 0:
    output.append('-'*(depth - 1) + '>' + element.tag)
  else:
    output.append(element.tag)

  if keys:
    maxKeySize = max([len(key) for key in keys])
    for key in keys:
      output.append('%s %s: %s' % (' '*depth, key + ' '*(maxKeySize - len(key)), element.attrib[key].encode('utf-8')))
  if element.text:
    stripped = element.text.strip()
    if _doIgnoreWhitespace and stripped:
      output.append(' '*depth + '  ' + stripped)
    else:
      output.append(' '*depth + '  ' + element.text)


def _shortenedAbsoluteFileName(dsxFile):
  head, tail = os.path.split(dsxFile)
  headHead, headTail = os.path.split(head)
  return os.path.join(headTail, tail).lower()


def _shortAbsoluteFileName(dsxFile):
  head, tail = os.path.split(dsxFile)
  return tail.lower()


def _compareStringCaseInsensitive(left, right):
  left = left.lower()
  right = right.lower()
  if left < right:
    return -1
  elif left > right:
    return 1
  else:
    return 0


def _compareFirstStringCaseInsensitive(left, right):
  left = left[0].lower()
  right = right[0].lower()
  if left < right:
    return -1
  elif left > right:
    return 1
  else:
    return 0


def _compareCaseInsensitive(left, right):
  leftDsxFile = left[0].lower()
  rightDsxFile = right[0].lower()
  leftKey = left[1].lower()
  rightKey = right[1].lower()

  if leftDsxFile < rightDsxFile:
    return -1
  elif leftDsxFile > rightDsxFile:
    return 1
  else:
    if leftKey < rightKey:
      return -1
    elif leftKey > rightKey:
      return 1
    else:
      return 0


def writeConfigurationReport(reportLines):
  configurationFile = open('configurationspecification.txt', 'w')
  for line in reportLines:
    configurationFile.write(line)
  configurationFile.close()


def _usage():
  print ""
  print "Usage: checksums[.py] [-c] [-w] [-d]"
  print "  <md5file1>: file name - result of 'appconf -md5"
  print "  <md5file2>: file name - result of 'appconf -md5"
  print "  calculates the MD5 digest for every file and writes it into the fil digest.md5."
  print "  with the option -c all temporary files are cleaned up at the end."
  print "  with the option -w all temporary filesempty lines are ignored for the checksum."
  print "  with the option -d the difference in buildtime objects between the project and the standard is caluclated."
  print "\nUse 'checksums[.py] -h' to get this message"
  sys.exit()


def _processOptions(options):
  validOptions = ['-c', '-w', '-d']

  for option in options:
    if option not in validOptions:
      print "ERROR: Invalid option (%s)" % (option)
      _usage ()

  if '-h' in options:
    _usage ()

  if '-c' in options:
    global _doCleanup
    _doCleanup = 1

  if '-w' in options:
    global _doIgnoreWhitespace
    _doIgnoreWhitespace = 1

  if '-d' in options:
    global _doCalculateDifference
    _doCalculateDifference = 1


if __name__ == '__main__':
  allOptions = []
  allArguments = []

  # process command line arguments, i.e. split them into options and parameter
  idx = 1
  while idx < len(sys.argv):
    if not string.find(sys.argv[idx], '-'):
      allOptions.append(sys.argv[idx])
    else:
      allArguments.append(sys.argv[idx])
    idx = idx + 1
  _processOptions (allOptions)

  createChecksums('.')
  configurationReportLines = []

  configurationReportLines.append('-' * 72 + '\n')
  configurationReportLines.append('Configuration Specification\n')
  configurationReportLines.append('-' * 72 + '\n\n')

  configurationReportLines.append('-' * 72 + '\n')
  configurationReportLines.append('1 - Application Parameters\n')
  configurationReportLines.append('-' * 72 + '\n\n')

  # if we have a description of the app parameters we include it
  parameters = []
  if (os.path.exists('applicationparameters.txt')):
    parameters = open('applicationparameters.txt', 'r').readlines()
    for line in parameters:
      configurationReportLines.append('  ' + line)
    configurationReportLines.append('\n')
    os.remove('applicationparameters.txt')

  configurationLines = extractConfiguration('.')
  for line in configurationLines:
    configurationReportLines.append('  ' + line)
  configurationReportLines.append('\n\n')

  configurationReportLines.append('-' * 72 + '\n')
  configurationReportLines.append('2 - Users and User Groups\n')
  configurationReportLines.append('-' * 72 + '\n\n')
  userLines = extractUsers('.')
  for line in userLines:
    configurationReportLines.append('  ' + line)
  configurationReportLines.append('\n\n')

  configurationReportLines.append('-' * 72 + '\n')
  configurationReportLines.append('3 - Rights\n')
  configurationReportLines.append('-' * 72 + '\n\n')
  accessRightsLines = extractAccessRights('.')
  for line in accessRightsLines:
    configurationReportLines.append('  ' + line)
  configurationReportLines.append('\n\n')

  if _doCalculateDifference:
    configurationReportLines.append('-' * 72 + '\n')
    configurationReportLines.append('4 - Buildtime Objects\n')
    configurationReportLines.append('-' * 72 + '\n\n')
    differentObjectsLines = calculateObjectDifferenceToStandard('.', forInstallation = 0)
    for line in differentObjectsLines:
      configurationReportLines.append('  ' + line)

  writeConfigurationReport(configurationReportLines)

  if _doCalculateDifference:
    differentObjectsLines = calculateObjectDifferenceToStandard('..', forInstallation = 1)

    installFile = open('allowed_objects.txt', 'w')
    installFile.write(_installFileHeader)
    differentObjectsLines.sort()

    # Locales must be modified, since the files contain underscores instead of brackets
    regExp = re.compile("^(locale-[^-]+[-])[_]([^_]+)[_]$")
    for line in differentObjectsLines:
      out = line
      if regExp.match(line):
        out = regExp.sub("\\1(\\2)", line)
      else:
        out = line
      installFile.write(out + '\n')
    installFile.close()
