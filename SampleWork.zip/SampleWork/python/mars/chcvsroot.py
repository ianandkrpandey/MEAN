"""
chcvsroot.py -- change the CVSROOT in CVS/Root files


   $RCSfile: chcvsroot.py,v $
    $Source: /var/cvs/ftps/ftps/tools/python/chcvsroot.py,v $
      $Date: 2011/07/27 09:30:52 $
    $Author: HPLang $
  $Revision: 1.1 $

"""


usage = """\
usage: chcvsroot [-l] {-u user|-r CVSROOT}

Change the CVSROOT in the CVS/Root files.
  -l            run locally (do not recurse)
  -u user       change username part of pserver CVSROOT only
  -r CVSROOT    replace whole CVSROOT
  -a            replace whole CVSROOT according to environment variable CVSROOT

"""

import os
import sys
import string
import glob
import getopt
import re


# get username out of pserver CVSROOT
pserverre = re.compile("(:pserver[^:]*:)([^)]*)(@.*)")


def walkfn(arg, dirname, filenames):
  user, cvsroot = arg
  if os.path.basename(dirname) != 'CVS':
    return
  print
  print dirname
  root = os.path.join(dirname, 'Root')
  fp = open(root)
  # read all (it should be one line only, but I leave the rest untouched)
  rootlines = fp.readlines()
  fp.close()
  print "  <", rootlines[0],
  if cvsroot:
    if rootlines[0] == cvsroot + "\n":
      return
    rootlines[0] = cvsroot + "\n"
  else:
    match = pserverre.match(rootlines[0])
    if match: # else no pserver, hence no username
      if user == match.group(2):
        return
      rootlines[0] = match.group(1) + user + match.group(3) + "\n"
    else:
      return
  print "  >", rootlines[0],
  os.rename(root, root + ".bak")
  fp = open(root, "w")
  for line in rootlines:
    fp.write(line)
  fp.close()
  os.remove(root + ".bak")


def main(argc, argv):
  norecurse = 0
  user = ''
  cvsroot = ''
  try:
    opts, args = getopt.getopt(sys.argv[1:], 'ahlu:r:')
  except getopt.error, msg:
    sys.stderr.write(usage)
    sys.stderr.write(str(msg))
    return 1
  for opt, arg in opts:
    if opt == '-h':
      sys.stderr.write(usage)
      return 1
    if opt == '-a':
      cvsroot = os.getenv("CVSROOT")
      if not cvsroot:
        sys.stderr.write(usage)
        sys.stderr.write("Environment variable 'CVSROOT' not set.")
        return 1
    elif opt == '-l':
      norecurse = 1
    elif opt == '-u':
      user = arg
    elif opt == '-r':
      cvsroot = arg
  if user and cvsroot or not (user or cvsroot):
    sys.stderr.write(usage)
    return 1

  if norecurse:
    walkfn((user, cvsroot), 'CVS', os.listdir('CVS'))
  else:
    os.path.walk('.', walkfn, (user, cvsroot))
  return 0


try:
  sys.exit(main(len(sys.argv), sys.argv))
except KeyboardInterrupt:
  sys.stderr.write("interrupted\n")



